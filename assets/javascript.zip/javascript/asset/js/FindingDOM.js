
// Using Tag Name
var tName = document.getElementsByTagName('p');
// tName.innerHTML = "I am the update paragraph";
document.getElementById('demo').innerHTML = 'This text is first in the Paradraph ;' + tName[0].innerHTML;

// Using ID
var element = document.getElementById('oldheading');
element.innerHTML = "NEW Heading Element";


// Using Class Name
function myStyle(){
  var sectionStyle = document.getElementsByClassName('section');
  sectionStyle[0].style.backgroundColor = "red";
}

// Remove A li
function myRemove(){
  var list = document.getElementById('myList');
  list.removeChild(list.childNodes[1]);
}

// Add A li
function myAppend(){
  var list = document.getElementById('myList');
  var node = document.createElement("li");
  var text = document.createTextNode("Tea");

  node.appendChild(text);
  document.getElementById("myList").appendChild(node);
}
// var cName = document.getElementsByClassName('intro').css  = "";

// var qSelect = document.querySelectorAll('p.intro').style.fontSize = "35px";