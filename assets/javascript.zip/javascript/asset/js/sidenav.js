function closeSlide() {
  document.getElementById('mySide').style.width = "0%";
  document.getElementById('Main').style.marginLeft = "0%";
}
function openNav() {
  document.getElementById('mySide').style.width = "20%";
  document.getElementById('Main').style.marginLeft = "20%";
}