// JAVASCRIPT VARIABLES DECLERATION or INITIALIZATION
var firstName;
var lastName;
var age;
var job;


// VARIABLE ASSIGNMENTS
firstName = "KAZUKI";
lastName = "KANNO";
age = 21;
job = "49ners food shop";

function Result() {
  document.getElementById('result').innerHTML = firstName + lastName + age + job;
  // = is assignment operator
}

// var number;
// // My Answer
// number = 10;
// function caluculate(){
//   document.getElementById('mycaluculation').innerHTML = number ;
//   document.getElementById('mycaluculationPlus').innerHTML = number += 5;
//   document.getElementById('mycaluculationSub').innerHTML = number -= 5;
//   document.getElementById('mycaluculationMulti').innerHTML = number *= 5;
//   document.getElementById('mycaluculationDiv').innerHTML = number /= 5 ;
//   document.getElementById('mycaluculationRemein').innerHTML = number %= 9  ;
// }

// Correct Answer
number = 10;
number += 5; //10 + 5 = number
number -= 5; //15 - 5 = number
number *= 2;
number /= 3;
number %= 2
// Updating The number

function myResultAssignment(){
  document.getElementById('assign').innerHTML = number;
}
function myResultAssignmentPlus(){
  number += 5;
  document.getElementById('assign').innerHTML = number;
}
function myResultAssignmentMinus(){
  number -= 5;
  document.getElementById('assign').innerHTML = number;
}
function myResultAssignmentMulti(){
  number *= 5;
  document.getElementById('assign').innerHTML = number;
}
function myResultAssignmentDivide(){
  number /= 5;
  document.getElementById('assign').innerHTML = number;
}
function myResultAssignmentBoeleam(){
  number %= 5;
  document.getElementById('assign').innerHTML = number;
}
