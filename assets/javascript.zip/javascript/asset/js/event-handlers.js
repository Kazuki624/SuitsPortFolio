function myChange(){
  var upperCase = document.getElementById('fName');
  upperCase.value = upperCase.value.toUpperCase();
}

// function onChange(){
//   var on = "WEICOME"
//   document.getElementById('greeting').innerHTML = on;
// }
// function outChange(){
//  var out = "Please come in again"
//  document.getElementById('greeting').innerHTML = out;
// }

function onChange(obj){
  obj.innerHTML = "Thank you !";
}
function outChange(obj){
  obj.innerHTML = "Please come again!!";
}