// function modal(){
//   document.getElementById('modal-container').style.display = "block";
// }


// function modalSecond() {
//   document.getElementById('Modal-back').style.display = "flex";
//   document.getElementById('Modal-back').style.justifyContent = "center";
//   document.getElementById('Modal-back').style.alignItems = "center";
// }
// function closeModal() {
//   document.getElementById('Modal-back').style.display = "none";
// }

function ImageClick1() {
  document.getElementById('ImageBack').style.display = "flex";
  document.getElementById('ImageBack').style.justifyContent = "center";
  document.getElementById('ImageBack').style.alignItems = "center";
}
function Close1() {
  document.getElementById('ImageBack').style.display = "none";
}


function ImageClick2() {
  document.getElementById('ImageBack2').style.display = "flex";
  document.getElementById('ImageBack2').style.justifyContent = "center";
  document.getElementById('ImageBack2').style.alignItems = "center";
}
function Close2() {
  document.getElementById('ImageBack2').style.display = "none";
}


function ImageClick3() {
  document.getElementById('ImageBack3').style.display = "flex";
  document.getElementById('ImageBack3').style.justifyContent = "center";
  document.getElementById('ImageBack3').style.alignItems = "center";
}
function Close3() {
  document.getElementById('ImageBack3').style.display = "none";
}