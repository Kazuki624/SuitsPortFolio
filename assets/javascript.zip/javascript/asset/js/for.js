function myForLoop(){
  var text = "";
  var i ;
  for (i = 0; i < 5; i++ ) {
    text += "The Nimber is :" + i + "<br>";
    // += means text(1) = text + 1
    // += means text(2) = text(1) + 1
    // += means text(3) = text(2) + 1
    // likely Updating
  }
  document.getElementById("demo-loop").innerHTML = text;
}


function myCars(){
  var myCars = [
                  "Bugatti",        
                  "Maseratti",      
                  "Lambo",          
                  "Ferarri",   
               ];
  result = "";
  var i ;
  var carLength = myCars.length;  
   //lenght means caluculate the number of the arrais.  lenght doesn't count the Date type 0, it could count form date tyoe #1
  for (i = 0; i < carLength ; i++){
    car = myCars[i];
    result += "Tis is The " + car + ".<br>";
  }
  document.getElementById('demo').innerHTML = result;
}