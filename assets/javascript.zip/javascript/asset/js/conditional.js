var a ="20";  //date type = string
var b =20;    //date type = number

function myIf(){
  if(a ==b){
    document.getElementById('demo').innerHTML = "TRUE!";
  }else{
    document.getElementById('demo').innerHTML = "FALSE!";
  }
  if(a === b){
    document.getElementById('demo').innerHTML = "TRUE!";
  }else{
    document.getElementById('demo').innerHTML = "FALSE!";
  }

}
var a =20;  //date type = string
var b =20;    //date type = number

function myIf2(){
  if(a >=b){
    document.getElementById('demo2').innerHTML = "TRUE!";
  }else{
    document.getElementById('demo2').innerHTML = "FALSE!";
  }
}


var male ="John";  //date type = string
var female ="ana";    //date type = number

function myIf3(){
  if(male == "John" && a >10){
    document.getElementById('demo3').innerHTML = "John is a male more than 10!";
  }else{
    document.getElementById('demo3').innerHTML = "FALSE!";
  }
}