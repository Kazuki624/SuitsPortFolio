function onChange1(){
  document.getElementById('defaultimage').src = "asset/image/man-with-luggage-bag-on-train-station-896768.jpg" ;
  document.getElementById('img1').src = "/Users/kannokazuki/Desktop/DesignAdvance/javascript/asset/image/smailey.png" ;
}
function outChange1(){
  document.getElementById('defaultimage').src = "/Users/kannokazuki/Desktop/DesignAdvance/javascript/asset/image/smailey.png" ;
  document.getElementById('img1').src = "asset/image/man-with-luggage-bag-on-train-station-896768.jpg" ;
}


function onChange2(){
  document.getElementById('defaultimage').src = "asset/image/sad_smiley.jpeg" ;
  document.getElementById('img2').src = "/Users/kannokazuki/Desktop/DesignAdvance/javascript/asset/image/smailey.png" ;
}
function outChange2(){
  document.getElementById('defaultimage').src = "/Users/kannokazuki/Desktop/DesignAdvance/javascript/asset/image/smailey.png" ;
  document.getElementById('img2').src = "asset/image/sad_smiley.jpeg" ;
}


function onChange3(){
  document.getElementById('defaultimage').src = "asset/image/white-iphone-xr-3586249.jpg" ;
  document.getElementById('img3').src = "/Users/kannokazuki/Desktop/DesignAdvance/javascript/asset/image/smailey.png" ;
}
function outChange3(){
  document.getElementById('defaultimage').src = "/Users/kannokazuki/Desktop/DesignAdvance/javascript/asset/image/smailey.png" ;
  document.getElementById('img3').src = "asset/image/white-iphone-xr-3586249.jpg" ;
}





// Correct Answer
function oldimage(){
  document.getElementById('defaultimage').src = "/Users/kannokazuki/Desktop/DesignAdvance/javascript/asset/image/smailey.png";
}
function onChange1(){
  document.getElementById('defaultimage').src = "asset/image/man-with-luggage-bag-on-train-station-896768.jpg";
}
function onChange2(){
  document.getElementById('defaultimage').src = "asset/image/sad_smiley.jpeg";
}
function onChange3(){
  document.getElementById('defaultimage').src = "asset/image/white-iphone-xr-3586249.jpg";
}


// 関数名が同じでもそれぞれのfunction（）にはいいているので、そのfunctionは独立しており独立しており、,localと言える



