function myfunction(){
  document.getElementById('demosto').innerHTML = Date();
}

// Rettribute The Image
function myImage(){
  document.getElementById('mytext').innerHTML = 'I am Happy';
  document.getElementById('mytext').style.fontSize = '50px';
  document.getElementById('myImage').src = 'asset/image/smailey.png' ;
  document.getElementById('myImage').style.width = '300px'
  document.getElementById('myImage').style.height = '300px'
}
function myImagesad(){
  document.getElementById('mytext').innerHTML = 'I am sad';
  document.getElementById('mytext').style.fontSize = '50px';
  document.getElementById('myImage').src = 'asset/image/sad_smiley.jpeg';
  document.getElementById('myImage').style.width = '300px';
  document.getElementById('myImage').style.height = '300px';
}

function mydisappear(){
document.getElementById('toggle').style.opacity = '0';
document.getElementById('toggle').style.transition = 'opacity 2s ease'
}
function myappear(){
document.getElementById('toggle').style.opacity = '1';
document.getElementById('toggle').style.transition = 'opacity 2s ease';
}
// document.write(5 + 10 + "I'm Kazuki");
// window.alert('This is ALERT BOX');
// console.log('5 + 20');