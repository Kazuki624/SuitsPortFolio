function  CloseNav() {
  document.getElementById('mySlideNav').style.width = "0%";
  document.getElementById('mySlideshow').style.marginLeft = "0%";
}

function OpenNav() {
  document.getElementById('mySlideNav').style.width = "20%";
  document.getElementById('mySlideshow').style.marginLeft = "20%";
}




var SlideIndex = 1;
ShowSlide(SlideIndex);
function PlusSlide(show) {
  ShowSlide(SlideIndex += show);
}
function currentSlide(show) {
  ShowSlide(SlideIndex = show);
}

function ShowSlide(show) {
  var slide = document.getElementsByClassName('sliders');
  var dot = document.getElementsByClassName('dot');
  var sLength = slide.length;
  var dLenght = dot.length;
  if(show > sLength) {
    SlideIndex = 1;
  }else if(show < 1) {
    SlideIndex = sLength;
  }

  for(i = 0; i < sLength; i++) {
    slide[i].style.display = "none";
  }
  for(i = 1; i < dLenght; i++) {
    dot[i].className = dot[i].className.replace(" active","");
  }

  slide[SlideIndex-1].style.display = "block";
  dot[SlideIndex-1].className += " active";
}


function ImageClick1() {
  document.getElementById('ImageBack').style.display = "flex";
  document.getElementById('ImageBack').style.justifyContent = "center";
  document.getElementById('ImageBack').style.alignItems = "center";
}
function Close1() {
  document.getElementById('ImageBack').style.display = "none";
}