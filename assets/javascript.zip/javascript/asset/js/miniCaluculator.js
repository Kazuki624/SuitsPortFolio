function caluculate(){
  var Num1 = parseInt(document.getElementById('num1').value);
  var Num2 = parseInt(document.getElementById('num2').value);
  // parseFloat means turn text out the Number.
  var Oparators = document.getElementById('operators').value;

  if(Oparators === '+') {
    document.getElementById('result').innerHTML = Num1 + Num2;
  }else if(Oparators === '-'){
    document.getElementById('result').innerHTML = Num1 - Num2;
  }else if (Oparators === '*'){
    document.getElementById('result').innerHTML = Num1 * Num2;
  }else if (Oparators === '/'){
    document.getElementById('result').innerHTML = Num1 / Num2;
  }
  // if(Oparators === '+') {
  //   document.getElementById('result').value = Num1 + Num2;
  // }else if(Oparators === '-'){
  //   document.getElementById('result').value = Num1 - Num2;
  // }else if (Oparators === '*'){
  //   document.getElementById('result').value = Num1 * Num2;
  // }else if (Oparators === '/'){
  //   document.getElementById('result').value = Num1 / Num2;
  // }
}
