var slideIndex = 1;

showSlide(slideIndex);
function PlusSlide(show){
  showSlide(slideIndex += show);
}
function currentSlide(show){
  showSlide(slideIndex = show)
}

function showSlide(show) {
  var slides = document.getElementsByClassName('slide');
  var sLength = slides.length;
  var dLength = dot.length;
  // 取り出した情報から数をカウント

    if(show > sLength) {
      slideIndex = 1;
    }else if(show < 1){
      slideIndex  = sLength
    }

    for(i = 0; i < sLength; i++) {
        slides[i].style.display = "none";
    }

    for(i = 1; i < dLength; i++){
      dot[i].className = dot[i].className.replace(" active","");
      //ドットのクラス名をアクティブに変換する。

    }
  slides[slideIndex-1].style.display = "block";
  //スライドインデックスが0になることでイメージが表示される
  dot[slideIndex-1].className += " active";
}