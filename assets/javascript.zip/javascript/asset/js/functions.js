var num =myNum(5,3);

document.getElementById('demo').innerHTML = num;
    function myNum (num1,num2) {
      return  num1 * num2;
    }

// var profile  = myProfile('Kazuki',21,'student');

// document.getElementById('greeting').innerHTML = profile;

function myProfile(name,age,job) {
   document.getElementById('greeting').innerHTML = "WELCOME" + " " + name + " " + age + " " + job + ".";
}
