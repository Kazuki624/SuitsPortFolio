function myCars(){
  var myCars = [
                  "Bugatti",        //array in Date type = 0
                  "Maseratti",      //array in Date type = 1
                  "Lambo",          //array in Date type = 2
                  "Ferarri",        //array in Date type = 3
                  2020,             //array in Date type = 4
                ]; 
  //put date types in the var(variable) of car(array).
  document.getElementById('demo').innerHTML = myCars;  //All Array'll be displayed
  document.getElementById('demo2').innerHTML = myCars [3];  //display only Date Type 3
  // var myCar = [myCars + "Toyota"]
  // document.getElementById('demo3').innerHTML = myCar;  


  myCars[4] = "Toyota";
  document.getElementById('demo3').innerHTML = myCars;  //i can update when i indicate the datetype array number and new content

  document.getElementById('demo4').innerHTML = myCars.join(" "); 
  // Due to .join(""), I can make the space between the array date types
  
  myCars.push("Audi");
  document.getElementById('demo5').innerHTML = myCars; 
  //Push means to add date type 

  myCars.pop();
  document.getElementById('demo6').innerHTML = myCars; 
  myCars.pop();
  document.getElementById('demo7').innerHTML = myCars; 
  //pop means eleminate the last date type
  
}