var slideIndex = 1;


//スライドの動きを操作する
showSlide(slideIndex);
function PlusSlide(show){
  showSlide(slideIndex += show);
}
function currentSlide(show){
  showSlide(slideIndex = show)
}

function showSlide(show) {
  var slides = document.getElementsByClassName('J-Slides');
  var dotImage = document.getElementsByClassName('dot-image');
  //HTMLからDotとmySlidesクラスの情報を取り出す
  var sLength = slides.length;
  var dLength = dotImage.length;
  // 取り出した情報から数をカウント

    if(show > sLength) {
      slideIndex = 1;
    }else if(show < 1){
      slideIndex  = sLength
    }

    for(i = 0; i < sLength; i++) {
        slides[i].style.display = "none";
    }

    for(i = 1; i < dLength; i++){
      dotImage[i].className = dotImage[i].className.replace(" active","");
      //ドットのクラス名をアクティブに変換する。

    }
  slides[slideIndex-1].style.display = "block";
  //スライドインデックスが0になることでイメージが表示される
  dotImage[slideIndex-1].className += " active";
}