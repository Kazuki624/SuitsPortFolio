$(document).ready(function(){

var doAniamtions = function() {
  var $offset = $(window).scrollTop() + $(window).height();

  var $animatables = $('.beforeAniamte');

  if($animatables.length == 0) {
    $(window).off('scroll', doAniamtions);
  }

  $animatables.each(function(i) {
    var $aniamtable = $(this);

    if(($aniamtable.offset().top + $aniamtable.height() - 20) < $offset) {
      $aniamtable.removeClass('beforeAnimate').addClass('animating');
    }
  });
}
  $(window).on('scroll', doAniamtions);
  $(window).trigger('scroll');
});