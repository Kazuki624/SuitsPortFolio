$(document).ready(function(){
  $("#demo").click(function(){
    // $("#img , #hide").toggle(1000);
    // $("#img1").toggle(1000);
    $("#img2").toggle(1000);
  });
});


$(document).ready(function(){
  $("#In").click(function(){
    $("#box1").fadeIn(1000);
  });  
  $("#Out").click(function(){
    $("#box1").fadeOut(1000);
  });  
  $("#Toggle").click(function(){
    $("#fadetoggle").fadeToggle(1000);
  });
  $("#To").click(function(){
    $("#fadeto").fadeTo(1000,0);
    $("#fadeto").fadeTo(1000,1);
  });
});

$(document).ready(function(){
  $("#Down").click(function(){
    $("#Sbox").slideDown(1000);
  });
  $("#Up").click(function(){
    $("#Sbox").slideUp(1000);
  });
  $("#SToggle").click(function(){
    $("#Sbox2").slideToggle(1000);
  });
});


