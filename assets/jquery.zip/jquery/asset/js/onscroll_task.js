$(document).ready(function(){

var doAnimations = function() {
  var $offset = $(window).scrollTop() + $(window).height();

  var $animatables = $('.beforeAnimate');
  // ＄つけ忘れ

  if($animatables.length == 0) {
      $(window).off('scroll', doAnimations);
  }

  $animatables.each(function(i) {
    var $animatable = $(this);

    if(($animatable.offset().top + $animatable.height() - 20) < $offset) {
      $animatable.removeClass('beforeAnimate').addClass('animating');
    }
  });
};
  $(window).on('scroll', doAnimations);
  $(window).trigger('scroll');
});

// $(document).ready(function(){

//   var doAnimations = function() {
//     var $offset = $(window).scrollTop() + $(window).height();
//     // sctollTopは開始の画面を示す
  
//     var $animatables = $('.beforeAnimate');
  
//     if($animatables.length == 0)  {
//         $(window).off('scroll', doAnimations);
//         // animatables要素の数が0だったら
//     }
  
//     $animatables.each(function(i){
//       var $animatable = $(this); //.・・・・・・➀
//         if(($animatable.offset().top + $animatable.height() - 20) < $offset) {
//            $animatable.removeClass('beforeAnimate').addClass('animating');
//           // スクロールした時の画面が表示されるまでの過程をここで行なっている。
//           //➀では現在のスクロール位置の場所を代入している。.
  
//         }
//     });
//   };
//     $(window).on('scroll', doAnimations);
//     $(window).trigger('scroll');
//   });