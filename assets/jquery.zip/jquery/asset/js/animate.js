$(document).ready(function(){
  $("#animate").click(function(){
    $("section").animate({

      top:'250px',
      height:'+=150px;',
      width:'+=150px',
      opcity:'0.5'
    
    });
  });
});

