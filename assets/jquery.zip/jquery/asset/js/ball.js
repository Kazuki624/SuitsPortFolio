// window.onload = function() {
//   var ball = document.getElementById('bBall');
  
//     ball.style.marginLeft = "50px";
// }

window.onload = function() {
  var load = document.getElementById('ScaleOn');
  var load1 = document.getElementById('box1');
  var load2 = document.getElementById('box2');
  var load3 = document.getElementById('box3');

  load.style.transform = "scale(1)";
  load1.style.transform = "scale(1)";
  load2.style.transform = "translate(0,0)";
  load3.style.transform = "scale(1)";
  // load.style.backgroundColor = "#ffffff" 
}
