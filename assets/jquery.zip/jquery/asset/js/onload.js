// function login() {
//   document.getElementById('loginform').style.display = "block";
//   document.getElementById('loginform').style.justifyContent = "center";
//   document.getElementById('loginform').style.alignItems = "center";
// }
// function Close() {
//   document.getElementById('loginform').style.display = "none";
// }


// var modal = document.getElementById('loginform');

// window.onclick = function(event) {
//   if (event.target == modal) {
//     modal.style.display = "none";
//   }
// document.getElementById('loginform').onload = function(){myOpen()};
  
// function myOpen(){
//     modal.style.display = "block";
//   }
// }


window.onload = function() {
  var ball = document.getElementById('bBall');
  
    ball.style.marginLeft = "50px";
}


// function myFunction() {
//   alert("Page is Loaded!!")
// }
